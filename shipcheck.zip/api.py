#!/usr/bin/env python3
"""ShipCheck API: POST /api/scan {url} -> report JSON; POST /api/lead {email,url} -> saved.
Stdlib only (no Flask needed) so it runs on any box with python3 + requests.
Run:  python3 api.py  (PORT env, default 8080). Serves index.html at /.
"""
import json, os, re, time, ipaddress, socket, threading
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from urllib.parse import urlparse
import scanner

HERE = os.path.dirname(os.path.abspath(__file__))
INDEX = os.path.join(HERE, "index.html")
LEADS = os.path.join(HERE, "data", "leads.jsonl")
SCANS = os.path.join(HERE, "data", "scans.jsonl")
os.makedirs(os.path.join(HERE, "data"), exist_ok=True)
RATE = {}  # ip -> [timestamps]
LOCK = threading.Lock()
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")

def rate_ok(ip, limit=10, window=3600):
    now = time.time()
    with LOCK:
        hits = [t for t in RATE.get(ip, []) if now - t < window]
        if len(hits) >= limit: RATE[ip] = hits; return False
        hits.append(now); RATE[ip] = hits; return True

def safe_target(url):
    """Block private/internal targets (SSRF guard)."""
    if not url.startswith("http"): url = "https://" + url
    p = urlparse(url)
    if p.scheme not in ("http", "https") or not p.hostname: return None
    try:
        for info in socket.getaddrinfo(p.hostname, None):
            ip = ipaddress.ip_address(info[4][0])
            if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved: return None
    except Exception:
        return None
    return url

class H(SimpleHTTPRequestHandler):
    def do_GET(self):
        # Serve only the landing page and a health check; never the source files.
        if self.path in ("/", "/index.html") or self.path.startswith("/?"):
            body = open(INDEX, "rb").read()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            for k, v in (("Strict-Transport-Security", "max-age=31536000"), ("X-Frame-Options", "DENY"),
                         ("X-Content-Type-Options", "nosniff"), ("Referrer-Policy", "strict-origin-when-cross-origin")):
                self.send_header(k, v)
            self.send_header("Content-Length", str(len(body)))
            self.end_headers(); self.wfile.write(body); return
        if self.path == "/healthz":
            return self._json(200, {"ok": True})
        return self._json(404, {"error": "not found"})

    def _json(self, code, obj):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers(); self.wfile.write(body)

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0) or 0)
        try: data = json.loads(self.rfile.read(min(n, 10000)) or b"{}")
        except Exception: return self._json(400, {"error": "bad json"})
        ip = self.headers.get("X-Forwarded-For", self.client_address[0]).split(",")[0].strip()
        if self.path == "/api/scan":
            if not rate_ok(ip): return self._json(429, {"error": "Too many scans. Try again in an hour."})
            url = safe_target(str(data.get("url", "")).strip())
            if not url: return self._json(400, {"error": "Enter a public URL."})
            res = scanner.scan(url)
            with open(SCANS, "a") as f:
                f.write(json.dumps({"t": time.time(), "url": url, "grade": res.get("grade"), "counts": res.get("counts")}) + "\n")
            return self._json(200, res)
        if self.path == "/api/lead":
            email = str(data.get("email", "")).strip()
            if not EMAIL_RE.match(email): return self._json(400, {"error": "Enter a valid email."})
            with open(LEADS, "a") as f:
                f.write(json.dumps({"t": time.time(), "email": email, "url": data.get("url", "")}) + "\n")
            return self._json(200, {"ok": True})
        return self._json(404, {"error": "not found"})

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8080))
    print(f"ShipCheck API on :{port}")
    ThreadingHTTPServer(("0.0.0.0", port), H).serve_forever()
